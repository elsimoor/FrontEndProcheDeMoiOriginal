"use client";

import { gql, useQuery, useMutation } from "@apollo/client";
import { useLanguage } from "@/context/LanguageContext";
import useTranslation from "@/hooks/useTranslation";

/**
 * AdminUsersPage
 *
 * This page allows administrators to view all registered users and
 * promote them to the admin role.  It lists each user’s name,
 * email and current role in a simple table.  A "Make Admin" button
 * appears for users who are not already admins.  When clicked the
 * updateUser mutation is invoked with the role set to "admin".  The
 * list is refetched upon completion to reflect the updated roles.
 */
const GET_USERS = gql`
  query GetUsers {
    users {
      id
      firstName
      lastName
      email
      role
    }
  }
`;

const UPDATE_USER_ROLE = gql`
  mutation UpdateUserRole($id: ID!, $input: UserUpdateInput!) {
    updateUser(id: $id, input: $input) {
      id
      role
    }
  }
`;

export default function AdminUsersPage() {
  const { t } = useTranslation();
  // Pull locale setter so the language switcher in the header updates
  const { locale, setLocale } = useLanguage();
  const { data, loading, error, refetch } = useQuery(GET_USERS);
  const [updateUserRole] = useMutation(UPDATE_USER_ROLE, {
    onCompleted: () => refetch(),
  });

  const handleMakeAdmin = (userId: string) => {
    updateUserRole({ variables: { id: userId, input: { role: "admin" } } });
  };

  if (loading) {
    return <p>Loading users...</p>;
  }
  if (error) {
    return <p>Error loading users.</p>;
  }
  const users = data?.users ?? [];
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold mb-4">Manage Users</h1>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 border">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
              <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.map((user: any) => (
              <tr key={user.id} className="hover:bg-gray-50">
                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900">
                  {user.firstName} {user.lastName}
                </td>
                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                  {user.email}
                </td>
                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500 capitalize">
                  {user.role}
                </td>
                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500 text-right">
                  {user.role !== "admin" ? (
                    <button
                      onClick={() => handleMakeAdmin(user.id)}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                      Make Admin
                    </button>
                  ) : (
                    <span className="text-green-600 font-semibold">Admin</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}